print('Always with you :)')
